public class Produc_Consum {
  public static void main(String[] args) {  
    
    Cola cola = new Cola();
	
    Productor prod = new Productor(cola, 1);	
	Consumidor cons1 = new Consumidor(cola, 2);
	Consumidor cons2 = new Consumidor(cola, 3);
	Consumidor cons3 = new Consumidor(cola, 4);
	Consumidor cons4 = new Consumidor(cola, 5);
	
    prod.start();
	cons1.start();
	  cons2.start();
	  cons3.start();
	  cons4.start();

  }
}